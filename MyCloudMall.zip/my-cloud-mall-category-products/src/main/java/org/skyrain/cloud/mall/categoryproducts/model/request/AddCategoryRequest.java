package org.skyrain.cloud.mall.categoryproducts.model.request;

import java.io.Serializable;

public class AddCategoryRequest implements Serializable {
    private String name;

    private Integer type;

    private Integer parentId;

    private Integer orderNum;

    @Override
    public String toString() {
        return "addCategoryRequest{" +
                "name='" + name + '\'' +
                ", type=" + type +
                ", parentId=" + parentId +
                ", orderNum=" + orderNum +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public Integer getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(Integer orderNum) {
        this.orderNum = orderNum;
    }
}
